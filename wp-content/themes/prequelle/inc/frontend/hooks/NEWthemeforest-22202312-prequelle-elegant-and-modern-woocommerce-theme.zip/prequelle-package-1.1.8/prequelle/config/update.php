<?php
/**
 * Update
 *
 * Update options and mods from previous version if needed
 *
 * @package WordPress
 * @subpackage Prequelle
 * @version 1.1.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
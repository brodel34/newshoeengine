<?php
/**
 * The secondary main navigation
 *
 * @package WordPress
 * @subpackage Prequelle
 * @version 1.1.8
 */

wp_nav_menu( prequelle_get_menu_args( 'secondary' ) );
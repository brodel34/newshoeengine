How to translate your theme:
https://wolfthemes.ticksy.com/article/11669/
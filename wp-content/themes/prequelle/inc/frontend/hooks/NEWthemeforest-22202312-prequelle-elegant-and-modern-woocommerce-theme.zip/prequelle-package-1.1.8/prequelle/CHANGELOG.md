#### 21th December 2018 - Version 1.1.8

* Fix: Login popup closing on Android

#### 6th December 2018 - Version 1.1.7

* Fix: Login popup closing on mobile
* Other: Updated WooCommerce templates version (3.5.2)
* Other: Updated WPBakery Page Builder (5.6)
* Other: Updated Slider Revolution (5.4.8.1)

#### 16th November 2018 - Version 1.1.3

* Fix: Deprecated add_to_cart_fragments filter
* Other: Updated WooCommerce templates version (3.5.1)

#### 17th October 2018 - Version 1.1.1

* Other: Updated WPBakery Page Builder (5.5.5)

#### 18th September 2018 - Version 1.1.0

* Fix: Various CSS issues
* Other: Updated WPBakery Page Builder (5.5.4)

#### 14th September 2018 - Version 1.0.9

* Fix: Minor CSS fixes
* Fix: Typo

#### 2nd August 2018 - Version 1.0.7

* Tweak: Added product module options (best selling, top rated)
* Tweak: Updated lightbox script (fancybox 3.3.5)
* Fix: On Sale product by category

#### 4th July 2018 - Version 1.0.4

* Fix: Missing customizer mods
* Fix: Minor CSS fixes
* Tweak: Added One-Page animation duration option
* Tweak: Added sticky product details option

#### 1st July 2017 - Version 1.0.0

* Initial release
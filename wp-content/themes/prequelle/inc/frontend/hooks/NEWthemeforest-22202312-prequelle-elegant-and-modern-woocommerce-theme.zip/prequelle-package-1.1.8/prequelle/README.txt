=== Prequelle ===
Requires at least: WordPress 4.5
Tested up to: WordPress 5.0.2
Version: 1.1.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, sticky-post, threaded-comments, translation-ready

Elegant and Modern WooCommerce Theme

== Description ==

Prequelle is modern and elegant e-commerce WordPress theme built for WooCoomerce plugin. It includes shop extended features like product quick view, user wishlist, dropdown cart panel, login popup and more. It is designed to be clean, user-friendly, secure and focused on performances. It includes all the features you need to create a professional online shop easily and quickly. It is made simple and functional out of the box, yet offer high customization for advanced users who want to build the best website for their client. It includes an extended version of WPBakery Page Builder ($46) and the Slider Revolution plugin ($26).

== Installation ==


== Changelog ==

%CHANGELOG%

Initial release

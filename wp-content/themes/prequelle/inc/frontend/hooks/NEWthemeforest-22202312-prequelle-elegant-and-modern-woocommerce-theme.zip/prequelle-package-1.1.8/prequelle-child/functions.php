<?php
/*
	This is the Prequelle child theme functions.php file.
	You can use this file to overwrite existing functions, filter and actions to customize the parent theme.
	https://wolfthemes.ticksy.com/article/11659/
*/
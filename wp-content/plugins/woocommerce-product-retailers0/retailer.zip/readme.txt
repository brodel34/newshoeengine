=== WooCommerce Product Retailers ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.4
Tested up to: 4.9.6

Allow customers to purchase products from external retailers

See http://docs.woocommerce.com/document/woocommerce-product-retailers/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-product-retailers' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
